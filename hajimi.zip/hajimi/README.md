# 哈基米 (Hajimi) — 小型枪战游戏

Three.js 第一人称 4v4 团队竞技（类穿越火线），用 Capacitor + GitHub Actions 打包成 Android APK。

## 上传到 GitHub 并出 APK
1. 新建仓库，把本目录全部文件推上去（`icon.png` 就是 App 图标，想换图标直接替换它）。
2. 打开仓库 → Actions → **Build APK** → Run workflow（推送到 main 也会自动跑）。
3. 跑完后在该次运行底部 **Artifacts → hajimi-apk** 下载 `app-debug.apk`，手机安装即可。

构建流程会自动：安装 three.js → 从 Poly Haven（CC0）联网下载砖墙/混凝土/柏油/金属/木板贴图并打进 APK → 生成各尺寸图标 → 锁定横屏全屏 → 编译。
贴图下载失败时游戏自动改用程序生成贴图，不影响出包。

## 本地预览
```
npm install && node scripts/copy-libs.mjs
bash scripts/fetch-textures.sh   # 可选
npx serve www                    # 或任意静态服务器，浏览器打开
```
电脑：WASD 移动 / 鼠标瞄准 / 左键开火 / R 换弹 / 空格跳 / 1·2·3·Q 换枪
手机：左半屏摇杆，右半屏滑动瞄准，按住开火键可边射边转视角。
