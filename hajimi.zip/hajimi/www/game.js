import * as THREE from './lib/three.module.js';

/* ================= 基础 ================= */
const $ = id => document.getElementById(id);
const isTouch = matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window;
if (isTouch) document.body.classList.add('touch');
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const wrapAng = a => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };

const CFG = { sens: 1, diff: 1, shadows: true, goal: 40, time: 360 };
const ARENA = 44;           // 场地半宽
const STEP = 0.55;          // 可自动踏上的台阶高度
const BODY_H = 1.8;

/* ================= 音效（WebAudio 合成） ================= */
let actx = null, NOISE = null;
function initAudio() {
  if (actx) { if (actx.state === 'suspended') actx.resume(); return; }
  try {
    actx = new (window.AudioContext || window.webkitAudioContext)();
    const len = actx.sampleRate * 0.6, buf = actx.createBuffer(1, len, actx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    NOISE = buf;
  } catch (e) { actx = null; }
}
function sfxShot(kind, vol = 1) {
  if (!actx || vol < 0.03) return;
  const t = actx.currentTime, big = kind === 'shotgun';
  const g = actx.createGain();
  g.gain.setValueAtTime(vol * (big ? 0.8 : 0.45), t);
  g.gain.exponentialRampToValueAtTime(0.001, t + (big ? 0.35 : 0.17));
  const s = actx.createBufferSource(); s.buffer = NOISE;
  const f = actx.createBiquadFilter(); f.type = 'lowpass';
  f.frequency.setValueAtTime(kind === 'pistol' ? 4000 : 2800, t);
  f.frequency.exponentialRampToValueAtTime(300, t + 0.16);
  s.connect(f); f.connect(g); g.connect(actx.destination); s.start(t); s.stop(t + 0.4);
  const o = actx.createOscillator(), og = actx.createGain();
  o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.12);
  og.gain.setValueAtTime(vol * 0.5, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
  o.connect(og); og.connect(actx.destination); o.start(t); o.stop(t + 0.2);
}
function sfxTone(freq, dur, vol = 0.15, type = 'square', slide = 0) {
  if (!actx) return;
  const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
}
const sfxHit = head => sfxTone(head ? 1500 : 900, 0.07, 0.18, 'triangle');
const sfxHurt = () => sfxTone(180, 0.18, 0.25, 'sawtooth', -100);

/* ================= 渲染器 / 场景 ================= */
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !isTouch, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, isTouch ? 1.5 : 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.shadowMap.type = THREE.PCFShadowMap;

const scene = new THREE.Scene();
const FOG = 0xc4d9ee;
scene.fog = new THREE.Fog(FOG, 70, 260);
const camera = new THREE.PerspectiveCamera(75, 1, 0.05, 600);
camera.rotation.order = 'YXZ';
scene.add(camera);

function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

const hemi = new THREE.HemisphereLight(0xcfe6ff, 0x6b6558, 1.15);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff0d8, 2.6);
sun.position.set(-40, 70, 30);
sun.castShadow = true;
sun.shadow.camera.left = -62; sun.shadow.camera.right = 62;
sun.shadow.camera.top = 62; sun.shadow.camera.bottom = -62;
sun.shadow.camera.near = 10; sun.shadow.camera.far = 200;
sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.05;
scene.add(sun);

// 天空穹顶
{
  const m = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(0x2f6fd0) }, mid: { value: new THREE.Color(0x8fc0f0) }, hor: { value: new THREE.Color(FOG) }, sunDir: { value: sun.position.clone().normalize() } },
    vertexShader: 'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
    fragmentShader: `varying vec3 vP; uniform vec3 top,mid,hor,sunDir;
      void main(){ vec3 d=normalize(vP); float h=clamp(d.y,0.0,1.0);
        vec3 c=mix(hor,mid,smoothstep(0.0,0.25,h)); c=mix(c,top,smoothstep(0.2,0.9,h));
        float s=max(dot(d,sunDir),0.0); c+=vec3(1.0,0.85,0.6)*(pow(s,600.0)*3.0+pow(s,8.0)*0.25);
        gl_FragColor=vec4(c,1.0);}`
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(450, 32, 16), m);
  sky.frustumCulled = false;
  scene.add(sky);
}

/* ================= 贴图：联网下载(CC0 Poly Haven，随 APK 打包)，失败则程序生成 ================= */
const TEXSETS = { brick: 3, concrete: 4, asphalt: 5, metal: 3, wood: 1.5 };
const TEX = {};          // name -> {map, normalMap, roughnessMap}
const loader = new THREE.TextureLoader();
function loadTex(url, srgb) {
  return new Promise(res => {
    const to = setTimeout(() => res(null), 12000);
    loader.load(url, t => {
      clearTimeout(to);
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.anisotropy = 4;
      if (srgb) t.colorSpace = THREE.SRGBColorSpace;
      res(t);
    }, undefined, () => { clearTimeout(to); res(null); });
  });
}
function cv(size = 256) { const c = document.createElement('canvas'); c.width = c.height = size; return [c, c.getContext('2d')]; }
function toTex(c) { const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; }
function speckle(g, n, size, base, spread, alpha = 0.35) {
  for (let i = 0; i < n; i++) {
    const v = base + (Math.random() - 0.5) * spread;
    g.fillStyle = `rgba(${v},${v},${v},${alpha})`;
    g.fillRect(Math.random() * 256, Math.random() * 256, size, size);
  }
}
const PROC = {
  brick() {
    const [c, g] = cv(); g.fillStyle = '#8c8279'; g.fillRect(0, 0, 256, 256);
    for (let r = 0; r < 8; r++) for (let i = -1; i < 4; i++) {
      const x = i * 64 + (r % 2 ? 32 : 0), y = r * 32;
      g.fillStyle = `hsl(${12 + Math.random() * 10},${38 + Math.random() * 12}%,${34 + Math.random() * 14}%)`;
      g.fillRect(x + 2, y + 2, 60, 28);
    }
    speckle(g, 900, 2, 90, 90, 0.18); return toTex(c);
  },
  concrete() {
    const [c, g] = cv(); g.fillStyle = '#9b9b97'; g.fillRect(0, 0, 256, 256);
    speckle(g, 2600, 2, 150, 70, 0.25); speckle(g, 50, 10, 140, 40, 0.12);
    g.strokeStyle = 'rgba(60,60,60,.35)'; g.beginPath(); g.moveTo(40, 0); g.lineTo(60, 90); g.lineTo(50, 150); g.stroke();
    return toTex(c);
  },
  asphalt() {
    const [c, g] = cv(); g.fillStyle = '#3d3d40'; g.fillRect(0, 0, 256, 256);
    speckle(g, 5000, 2, 90, 100, 0.35); return toTex(c);
  },
  metal() {
    const [c, g] = cv();
    for (let i = 0; i < 16; i++) { g.fillStyle = i % 2 ? '#8a9199' : '#a7aeb6'; g.fillRect(i * 16, 0, 16, 256); }
    for (let i = 0; i < 30; i++) { g.fillStyle = `rgba(120,70,30,${rand(0.05, 0.25)})`; g.fillRect(Math.random() * 256, Math.random() * 256, rand(6, 30), rand(6, 40)); }
    return toTex(c);
  },
  wood() {
    const [c, g] = cv(); g.fillStyle = '#9a7040'; g.fillRect(0, 0, 256, 256);
    for (let p = 0; p < 4; p++) {
      g.fillStyle = `hsl(30,${35 + Math.random() * 15}%,${34 + Math.random() * 14}%)`; g.fillRect(0, p * 64 + 2, 256, 60);
      for (let l = 0; l < 14; l++) { g.strokeStyle = 'rgba(50,30,10,.3)'; g.beginPath(); const y = p * 64 + rand(4, 60); g.moveTo(0, y); g.lineTo(256, y + rand(-3, 3)); g.stroke(); }
    }
    return toTex(c);
  }
};
async function loadAllTextures(setProgress) {
  let manifest = {};
  try { const r = await fetch('assets/tex/manifest.json'); if (r.ok) manifest = await r.json(); } catch (e) { }
  let done = 0; const names = Object.keys(TEXSETS);
  await Promise.all(names.map(async name => {
    const m = manifest[name], set = {};
    if (m) {
      set.map = await loadTex(`assets/tex/${name}_diff.jpg`, true);
      if (set.map) {
        if (m.nor) set.normalMap = await loadTex(`assets/tex/${name}_nor.jpg`, false);
        if (m.rough) set.roughnessMap = await loadTex(`assets/tex/${name}_rough.jpg`, false);
        set.real = true;
      }
    }
    if (!set.map) set.map = PROC[name]();
    TEX[name] = set; setProgress(++done, names.length);
  }));
}
const matCache = {};
function getMat(name, tint = 0xffffff) {
  const key = name + tint;
  if (matCache[key]) return matCache[key];
  const t = TEX[name];
  const m = new THREE.MeshStandardMaterial({
    map: t.map, normalMap: t.normalMap || null, roughnessMap: t.roughnessMap || null,
    color: tint, roughness: 0.92, metalness: name === 'metal' ? 0.45 : 0.02
  });
  if (t.normalMap) m.normalScale.set(0.9, 0.9);
  return (matCache[key] = m);
}

/* ================= 地图构建 ================= */
const colliders = [];   // {minX,maxX,minY,maxY,minZ,maxZ}
function boxGeo(w, h, d, tile) {
  const g = new THREE.BoxGeometry(w, h, d), uv = g.attributes.uv;
  const spans = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) {
    const k = f * 4 + i; uv.setXY(k, uv.getX(k) * spans[f][0] / tile, uv.getY(k) * spans[f][1] / tile);
  }
  return g;
}
function addBox(cx, y0, cz, w, h, d, matName, o = {}) {
  const mesh = new THREE.Mesh(boxGeo(w, h, d, o.tile || TEXSETS[matName] || 3), getMat(matName, o.tint ?? 0xffffff));
  mesh.position.set(cx, y0 + h / 2, cz);
  mesh.castShadow = o.cast !== false; mesh.receiveShadow = true;
  scene.add(mesh);
  if (o.collide !== false) colliders.push({ minX: cx - w / 2, maxX: cx + w / 2, minY: y0, maxY: y0 + h, minZ: cz - d / 2, maxZ: cz + d / 2 });
  return mesh;
}
// 带门窗洞口的直墙
function wallLine(axis, c, s, e, h, t, matName, openings = [], tint = 0xffffff) {
  const seg = (a, b, y0, y1) => {
    if (b - a < 0.01 || y1 - y0 < 0.01) return;
    if (axis === 'x') addBox((a + b) / 2, y0, c, b - a, y1 - y0, t, matName, { tint });
    else addBox(c, y0, (a + b) / 2, t, y1 - y0, b - a, matName, { tint });
  };
  let cur = s;
  [...openings].sort((p, q) => p.c - q.c).forEach(o => {
    const l = o.c - o.w / 2, r = o.c + o.w / 2;
    if (l > cur) seg(cur, l, 0, h);
    if (o.y0 > 0) seg(l, r, 0, o.y0);
    if (o.y1 < h) seg(l, r, o.y1, h);
    cur = r;
  });
  if (cur < e) seg(cur, e, 0, h);
}
const DOOR = (o, w = 3) => ({ o, w, y0: 0, y1: 2.8 });
const WIN = (o, w = 2.2) => ({ o, w, y0: 1.1, y1: 2.5 });
function building(cx, cz, w, d, h, matName, cfg, tint = 0xffffff) {
  const t = 0.5, x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
  const abs = (list, center) => (list || []).map(o => ({ c: center + o.o, w: o.w, y0: o.y0, y1: o.y1 }));
  wallLine('x', z0, x0, x1, h, t, matName, abs(cfg.N, cx), tint);
  wallLine('x', z1, x0, x1, h, t, matName, abs(cfg.S, cx), tint);
  wallLine('z', x0, z0 + t / 2, z1 - t / 2, h, t, matName, abs(cfg.W, cz), tint);
  wallLine('z', x1, z0 + t / 2, z1 - t / 2, h, t, matName, abs(cfg.E, cz), tint);
  addBox(cx, h, cz, w + 0.8, 0.4, d + 0.8, 'concrete', { tint: 0x77777a, tile: 4 });
  addBox(cx, 0, cz, w - 0.6, 0.04, d - 0.6, 'concrete', { collide: false, cast: false, tint: 0xb0b0b0 });
  // 室内灯
  const lamp = new THREE.Mesh(new THREE.BoxGeometry(Math.min(4, w * 0.4), 0.1, 0.5), new THREE.MeshBasicMaterial({ color: 0xfff2c8 }));
  lamp.position.set(cx, h - 0.1, cz); scene.add(lamp);
  const pl = new THREE.PointLight(0xffe8b0, 14, Math.max(w, d) * 1.2, 1.6); pl.position.set(cx, h - 0.8, cz); scene.add(pl);
}
function crate(x, z, s = 1.5, y0 = 0, tint = 0xffffff) { return addBox(x, y0, z, s, s, s, 'wood', { tint, tile: s }); }
function container(x, z, w, d, color, rotated) {
  const L = 6, Wd = 2.5, H = 2.6;
  const m = addBox(x, 0, z, rotated ? Wd : L, H, rotated ? L : Wd, 'metal', { tint: color, tile: 2.6 });
  return m;
}
function barrel(x, z, color = 0xb23b2e) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.1, 14), new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.6 }));
  m.position.set(x, 0.55, z); m.castShadow = m.receiveShadow = true; scene.add(m);
  colliders.push({ minX: x - 0.4, maxX: x + 0.4, minY: 0, maxY: 1.1, minZ: z - 0.4, maxZ: z + 0.4 });
}
function lamppost(x, z) {
  const p = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 6, 8), new THREE.MeshStandardMaterial({ color: 0x333840, metalness: 0.6, roughness: 0.5 }));
  p.position.set(x, 3, z); p.castShadow = true; scene.add(p);
  const h = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), new THREE.MeshBasicMaterial({ color: 0xfff1c0 }));
  h.position.set(x, 6.1, z); scene.add(h);
  colliders.push({ minX: x - 0.15, maxX: x + 0.15, minY: 0, maxY: 6, minZ: z - 0.15, maxZ: z + 0.15 });
}

function buildMap() {
  // 地面
  const gTex = TEX.asphalt.map; gTex.repeat.set(300 / 5, 300 / 5);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), new THREE.MeshStandardMaterial({
    map: gTex, normalMap: TEX.asphalt.normalMap || null, roughnessMap: TEX.asphalt.roughnessMap || null, roughness: 0.95
  }));
  if (TEX.asphalt.normalMap) TEX.asphalt.normalMap.repeat.copy(gTex.repeat);
  if (TEX.asphalt.roughnessMap) TEX.asphalt.roughnessMap.repeat.copy(gTex.repeat);
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  // 路面标线
  const paint = new THREE.MeshBasicMaterial({ color: 0xe8c64a });
  for (let i = -40; i < 40; i += 6) {
    const a = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.25), paint); a.rotation.x = -Math.PI / 2; a.position.set(i, 0.02, -8); scene.add(a);
    const b = new THREE.Mesh(new THREE.PlaneGeometry(0.25, 3), paint); b.rotation.x = -Math.PI / 2; b.position.set(8, 0.02, i); scene.add(b);
  }

  // 围墙
  const H = 6, T = 1;
  addBox(0, 0, -ARENA - T / 2, ARENA * 2 + 2 * T, H, T, 'concrete', { tint: 0xbdbdbd, tile: 4 });
  addBox(0, 0, ARENA + T / 2, ARENA * 2 + 2 * T, H, T, 'concrete', { tint: 0xbdbdbd, tile: 4 });
  addBox(-ARENA - T / 2, 0, 0, T, H, ARENA * 2, 'concrete', { tint: 0xbdbdbd, tile: 4 });
  addBox(ARENA + T / 2, 0, 0, T, H, ARENA * 2, 'concrete', { tint: 0xbdbdbd, tile: 4 });

  // 建筑
  building(-22, -20, 16, 12, 6, 'brick', { N: [DOOR(0), WIN(-5.5), WIN(5.5)], S: [DOOR(-3), WIN(4)], E: [WIN(-2.5), WIN(2.5)], W: [DOOR(0)] });
  building(24, -22, 14, 14, 7, 'concrete', { W: [DOOR(-2), WIN(3.5)], S: [DOOR(2)], N: [WIN(0)], E: [WIN(-3), WIN(3)] }, 0xd0d0d0);
  building(20, 22, 18, 10, 5.5, 'brick', { E: [DOOR(0)], W: [DOOR(0), WIN(3.2)], N: [WIN(-5), WIN(0), WIN(5)], S: [DOOR(-4), WIN(4)] }, 0xe0c8b8);
  building(-24, 22, 12, 16, 6, 'concrete', { E: [DOOR(-3), WIN(3)], N: [DOOR(0)], S: [WIN(0)], W: [WIN(-3), WIN(3)] }, 0xc4c4cc);

  // 中央高台 + 阶梯（狙击位）
  addBox(0, 0, 0, 8, 3, 8, 'concrete', { tint: 0xb8b8b8, tile: 4 });
  for (let i = 0; i < 6; i++) addBox(0, 0, 8.95 - i * 0.9, 3, 0.5 * (i + 1), 0.9, 'concrete', { tint: 0xa8a8a8, tile: 2 });
  addBox(0, 3, -3.85, 8, 1, 0.3, 'concrete', { tint: 0x999999 });
  addBox(-3.85, 3, 0, 0.3, 1, 7.4, 'concrete', { tint: 0x999999 });
  addBox(3.85, 3, 0, 0.3, 1, 7.4, 'concrete', { tint: 0x999999 });

  // 集装箱
  container(-6, -10, 0, 0, 0x2f6db5, false);
  container(8, -14, 0, 0, 0xb8452f, true);
  container(-12, 10, 0, 0, 0x3d8a4a, true);
  container(12, 6, 0, 0, 0xd0a23a, false);
  container(-34, 0, 0, 0, 0x8a3fb0, true);
  container(34, 2, 0, 0, 0x2f6db5, true);
  container(2, 30, 0, 0, 0xb8452f, false);
  container(-2, -33, 0, 0, 0x3d8a4a, false);
  addBox(-6, 2.6, -10, 6, 2.6, 2.5, 'metal', { tint: 0xb8452f, tile: 2.6 });   // 叠放的第二层

  // 木箱
  [[-16, -4], [-17.6, -4], [-16.8, -4, 1.5, 1.5], [14, -2], [15.6, -2], [-4, 18], [-5.6, 18], [6, -24], [7.6, -24], [30, 12], [31.6, 12], [-30, -6], [-30, -7.6], [26, -6], [-8, -26], [10, 24], [-20, 4], [32, -8]]
    .forEach(a => crate(a[0], a[1], 1.5, a[3] || 0, a[2] ? 0xd8b080 : 0xffffff));
  crate(14.8, -2, 1.5, 1.5, 0xc89a60);

  // 沙袋/矮墙 (可跳过)
  [[-10, -2, 5, .6], [10, -8, .6, 5], [4, 14, 5, .6], [-14, 18, .6, 5], [36, -18, 5, .6], [-36, 14, 5, .6], [14, -32, .6, 5], [-26, -34, 5, .6], [28, 32, 5, .6], [-8, 34, .6, 5]]
    .forEach(a => addBox(a[0], 0, a[1], a[2], 1.1, a[3], 'concrete', { tint: 0xc8b898, tile: 2 }));

  // 桶、路灯
  [[-3, 8], [-3.9, 8.5], [3, -9], [-26, 0], [26, 8], [0, -26], [-18, 28], [-16, -30], [18, -34], [36, 24]].forEach((a, i) => barrel(a[0], a[1], i % 2 ? 0xb23b2e : 0x2f6db5));
  [[-10, -8], [10, 10], [-30, -10], [32, -8], [-12, 28], [14, -28], [-4, 40], [4, -40]].forEach(a => lamppost(a[0], a[1]));

  // 远景城市天际线
  const wt = (() => {
    const [c, g] = cv(128); g.fillStyle = '#2a3342'; g.fillRect(0, 0, 128, 128);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) { g.fillStyle = Math.random() < 0.35 ? '#ffe9a8' : '#4a5a74'; g.fillRect(x * 16 + 3, y * 16 + 3, 10, 10); }
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; return t;
  })();
  for (let i = 0; i < 70; i++) {
    const a = i / 70 * Math.PI * 2 + rand(-0.03, 0.03), r = rand(72, 130);
    const w = rand(10, 24), d = rand(10, 24), h = rand(18, 70);
    const m = new THREE.Mesh(boxGeo(w, h, d, 14), new THREE.MeshLambertMaterial({ map: wt, color: new THREE.Color().setHSL(rand(0.55, 0.65), 0.15, rand(0.5, 0.85)) }));
    m.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r); scene.add(m);
  }
}

/* ================= 碰撞 / 射线 ================= */
function blocked(x, z, y, r) {
  for (const c of colliders) {
    if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r && y < c.maxY - STEP && y + BODY_H > c.minY) return true;
  }
  return false;
}
function groundAt(x, z, y) {
  let g = 0;
  for (const c of colliders) {
    if (x > c.minX - 0.1 && x < c.maxX + 0.1 && z > c.minZ - 0.1 && z < c.maxZ + 0.1 && c.maxY <= y + STEP && c.maxY > g) g = c.maxY;
  }
  return g;
}
function moveEnt(e, dx, dz) {
  if (!blocked(e.x + dx, e.z, e.y, e.r)) e.x += dx;
  if (!blocked(e.x, e.z + dz, e.y, e.r)) e.z += dz;
  e.x = clamp(e.x, -ARENA + e.r, ARENA - e.r); e.z = clamp(e.z, -ARENA + e.r, ARENA - e.r);
}
function physY(e, dt) {
  const g = groundAt(e.x, e.z, e.y);
  e.vy -= 22 * dt; e.y += e.vy * dt;
  if (e.y <= g) { e.y = g; e.vy = 0; e.ground = true; } else e.ground = false;
  // 头顶碰撞
  for (const c of colliders) {
    if (e.x > c.minX - e.r && e.x < c.maxX + e.r && e.z > c.minZ - e.r && e.z < c.maxZ + e.r && e.vy > 0 && e.y + BODY_H > c.minY && e.y + BODY_H < c.minY + 0.6 && e.y < c.minY) { e.vy = 0; e.y = c.minY - BODY_H; }
  }
}
// 射线 vs AABB：返回 t 或 Infinity
function rayBox(ox, oy, oz, dx, dy, dz, minX, maxX, minY, maxY, minZ, maxZ) {
  let t0 = 0, t1 = Infinity, a, b, tmp;
  if (Math.abs(dx) < 1e-9) { if (ox < minX || ox > maxX) return Infinity; }
  else { a = (minX - ox) / dx; b = (maxX - ox) / dx; if (a > b) { tmp = a; a = b; b = tmp; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return Infinity; }
  if (Math.abs(dy) < 1e-9) { if (oy < minY || oy > maxY) return Infinity; }
  else { a = (minY - oy) / dy; b = (maxY - oy) / dy; if (a > b) { tmp = a; a = b; b = tmp; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return Infinity; }
  if (Math.abs(dz) < 1e-9) { if (oz < minZ || oz > maxZ) return Infinity; }
  else { a = (minZ - oz) / dz; b = (maxZ - oz) / dz; if (a > b) { tmp = a; a = b; b = tmp; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return Infinity; }
  return t0;
}
function rayWorld(ox, oy, oz, dx, dy, dz, maxD) {
  let best = maxD;
  for (const c of colliders) {
    const t = rayBox(ox, oy, oz, dx, dy, dz, c.minX, c.maxX, c.minY, c.maxY, c.minZ, c.maxZ);
    if (t < best) best = t;
  }
  return best;
}
function hasLOS(ax, ay, az, bx, by, bz) {
  const dx = bx - ax, dy = by - ay, dz = bz - az, L = Math.hypot(dx, dy, dz);
  return rayWorld(ax, ay, az, dx / L, dy / L, dz / L, L) >= L - 0.2;
}

/* ================= 特效池 ================= */
const fxGeo = new THREE.SphereGeometry(0.06, 6, 5);
const fxPool = [];
for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(fxGeo, new THREE.MeshBasicMaterial({ color: 0xffd080, transparent: true })); m.visible = false; m.userData = { life: 0, v: new THREE.Vector3() }; scene.add(m); fxPool.push(m); }
let fxI = 0;
function spark(p, color = 0xffd080, n = 4) {
  for (let k = 0; k < n; k++) {
    const m = fxPool[fxI++ % fxPool.length]; m.visible = true; m.position.copy(p); m.material.color.setHex(color); m.material.opacity = 1;
    m.userData.life = rand(0.2, 0.4); m.userData.v.set(rand(-2, 2), rand(0.5, 3), rand(-2, 2)); m.scale.setScalar(rand(0.8, 1.6));
  }
}
const tracers = [];
for (let i = 0; i < 24; i++) {
  const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(0, 0, -1)]);
  const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0xfff0a0, transparent: true, opacity: 0 })); l.frustumCulled = false; l.userData.life = 0; scene.add(l); tracers.push(l);
}
let trI = 0;
function tracer(a, b) {
  const l = tracers[trI++ % tracers.length]; const pos = l.geometry.attributes.position;
  pos.setXYZ(0, a.x, a.y, a.z); pos.setXYZ(1, b.x, b.y, b.z); pos.needsUpdate = true; l.material.opacity = 0.9; l.userData.life = 0.07;
}
function updateFx(dt) {
  for (const m of fxPool) if (m.visible) {
    const u = m.userData; u.life -= dt; if (u.life <= 0) { m.visible = false; continue; }
    u.v.y -= 9 * dt; m.position.addScaledVector(u.v, dt); m.material.opacity = u.life * 3;
  }
  for (const l of tracers) if (l.userData.life > 0) { l.userData.life -= dt; l.material.opacity = Math.max(0, l.userData.life / 0.07) * 0.9; }
}

/* ================= 武器 ================= */
const WEAPONS = [
  { id: 'rifle', name: '突击步枪', dmg: 28, rof: 0.095, mag: 30, reserve: 120, spread: 0.012, recoil: 0.011, auto: true, reload: 1.8, range: 120, pellets: 1 },
  { id: 'pistol', name: '手枪', dmg: 34, rof: 0.2, mag: 12, reserve: 60, spread: 0.006, recoil: 0.015, auto: false, reload: 1.2, range: 90, pellets: 1 },
  { id: 'shotgun', name: '霰弹枪', dmg: 13, rof: 0.85, mag: 6, reserve: 30, spread: 0.055, recoil: 0.07, auto: false, reload: 2.3, range: 35, pellets: 8 }
];
const P = {   // 玩家
  x: 0, y: 0, z: 0, vy: 0, r: 0.4, ground: true, yaw: 0, pitch: 0, hp: 100, alive: true, team: 'blue', name: '你',
  wi: 0, w: WEAPONS.map(w => ({ mag: w.mag, reserve: w.reserve })), reloading: 0, swap: 0, fireCD: 0, kick: 0, deadT: 0, bob: 0, kills: 0, deaths: 0, lastHit: 0
};
function curW() { return WEAPONS[P.wi]; }
function curS() { return P.w[P.wi]; }

// 第一人称枪模
const gunMat = new THREE.MeshStandardMaterial({ color: 0x23262b, metalness: 0.7, roughness: 0.4 });
const gunMat2 = new THREE.MeshStandardMaterial({ color: 0x5a4632, metalness: 0.1, roughness: 0.8 });
function mk(w, h, d, x, y, z, m = gunMat) { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); b.position.set(x, y, z); return b; }
function cyl(r, l, x, y, z, m = gunMat) { const c = new THREE.Mesh(new THREE.CylinderGeometry(r, r, l, 10), m); c.rotation.x = Math.PI / 2; c.position.set(x, y, z); return c; }
const flashTex = (() => { const [c, g] = cv(64); const gr = g.createRadialGradient(32, 32, 2, 32, 32, 30); gr.addColorStop(0, '#fff'); gr.addColorStop(.3, '#ffd070'); gr.addColorStop(1, 'rgba(255,120,20,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
function makeGun(id) {
  const g = new THREE.Group();
  if (id === 'rifle') {
    g.add(mk(0.07, 0.1, 0.5, 0, 0, 0), cyl(0.018, 0.4, 0, 0.02, -0.42), mk(0.05, 0.16, 0.08, 0, -0.12, -0.05), mk(0.06, 0.1, 0.3, 0, -0.02, 0.38, gunMat2), mk(0.03, 0.04, 0.12, 0, 0.075, -0.1), mk(0.06, 0.06, 0.2, 0, -0.04, -0.28, gunMat2));
    g.userData.muz = new THREE.Vector3(0, 0.02, -0.64);
  } else if (id === 'pistol') {
    g.add(mk(0.055, 0.075, 0.26, 0, 0, 0), mk(0.05, 0.14, 0.07, 0, -0.1, 0.07, gunMat2), cyl(0.014, 0.1, 0, 0.005, -0.17));
    g.userData.muz = new THREE.Vector3(0, 0.01, -0.24);
  } else {
    g.add(mk(0.07, 0.09, 0.45, 0, 0, 0), cyl(0.022, 0.6, 0, 0.03, -0.45), cyl(0.02, 0.5, 0, -0.02, -0.4), mk(0.075, 0.07, 0.16, 0, -0.045, -0.3, gunMat2), mk(0.06, 0.12, 0.3, 0, -0.04, 0.34, gunMat2));
    g.userData.muz = new THREE.Vector3(0, 0.03, -0.78);
  }
  const f = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.4), new THREE.MeshBasicMaterial({ map: flashTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  f.position.copy(g.userData.muz); f.visible = false; g.add(f); g.userData.flash = f;
  g.traverse(o => { if (o.isMesh) o.frustumCulled = false; });
  return g;
}
const guns = WEAPONS.map(w => makeGun(w.id));
const gunRoot = new THREE.Group(); gunRoot.position.set(0.22, -0.2, -0.45); camera.add(gunRoot);
guns.forEach((g, i) => { g.visible = i === 0; gunRoot.add(g); });
let flashT = 0;

function setWeapon(i) {
  if (i === P.wi || !P.alive) return;
  P.wi = i; P.reloading = 0; P.swap = 0.35;
  guns.forEach((g, k) => g.visible = k === i);
  sfxTone(500, 0.05, 0.1); updateHUD();
}
function startReload() {
  const w = curW(), s = curS();
  if (P.reloading > 0 || s.mag >= w.mag || s.reserve <= 0 || !P.alive) return;
  P.reloading = w.reload; sfxTone(300, 0.06, 0.15); setTimeout(() => sfxTone(520, 0.05, 0.15), 350);
}
function finishReload() {
  const w = curW(), s = curS(), need = w.mag - s.mag, take = Math.min(need, s.reserve);
  s.mag += take; s.reserve -= take; sfxTone(700, 0.06, 0.15); updateHUD();
}

/* ================= 角色（机器人） ================= */
const bots = [];
const TEAM_COL = { blue: 0x3a78d8, red: 0xd8443a };
const SPAWN = {
  blue: [[-37, 36], [-33, 38], [-39, 31], [-35, 33]],
  red: [[37, -36], [33, -38], [39, -31], [35, -33]]
};
const NAMES = ['小哈', '米米', '咪咪', '大橘', '花花', '团子', '奶盖', '布丁', '芝士', '汤圆', '年糕', '豆包'];
const skinMat = new THREE.MeshStandardMaterial({ color: 0xe8c4a0, roughness: 0.8 });
const darkMat = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.6 });
function makeBotMesh(team) {
  const g = new THREE.Group();
  const cm = new THREE.MeshStandardMaterial({ color: TEAM_COL[team], roughness: 0.7 });
  const pm = new THREE.MeshStandardMaterial({ color: 0x353a42, roughness: 0.8 });
  const add = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = true; g.add(o); return o; };
  add(new THREE.BoxGeometry(0.22, 0.8, 0.26), pm, -0.14, 0.4, 0);
  add(new THREE.BoxGeometry(0.22, 0.8, 0.26), pm, 0.14, 0.4, 0);
  add(new THREE.BoxGeometry(0.58, 0.7, 0.32), cm, 0, 1.15, 0);
  add(new THREE.SphereGeometry(0.17, 12, 10), skinMat, 0, 1.68, 0);
  add(new THREE.SphereGeometry(0.19, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), darkMat, 0, 1.7, 0);
  add(new THREE.BoxGeometry(0.14, 0.55, 0.16), cm, -0.36, 1.2, -0.15).rotation.x = -0.9;
  add(new THREE.BoxGeometry(0.14, 0.55, 0.16), cm, 0.34, 1.2, -0.15).rotation.x = -0.9;
  add(new THREE.BoxGeometry(0.07, 0.1, 0.7), darkMat, 0.1, 1.3, -0.5);
  return g;
}
function spawnPoint(team) { const l = SPAWN[team]; const s = l[(Math.random() * l.length) | 0]; return [s[0] + rand(-1, 1), s[1] + rand(-1, 1)]; }
function newBot(team, name) {
  const b = { team, name, x: 0, y: 0, z: 0, vy: 0, r: 0.4, ground: true, yaw: 0, hp: 100, alive: true, dead: 0, target: null, losT: Math.random() * 0.3, react: 0, fireT: 0, burst: 0, wp: null, strafe: Math.random() < 0.5 ? 1 : -1, strafeT: 0, stuckT: 0, lx: 0, lz: 0, seen: false, seenT: 0, grp: makeBotMesh(team), kills: 0 };
  scene.add(b.grp); respawnBot(b); return b;
}
function respawnBot(b) {
  const [x, z] = spawnPoint(b.team); b.x = x; b.z = z; b.y = 0; b.vy = 0; b.hp = 100; b.alive = true; b.dead = 0; b.target = null; b.wp = null; b.grp.rotation.x = 0; b.grp.visible = true;
  b.yaw = b.team === 'blue' ? -Math.PI * 0.75 : Math.PI * 0.25;
}
// 随机巡逻点（避开障碍）
const WAYPOINTS = [];
function genWaypoints() {
  let tries = 0;
  while (WAYPOINTS.length < 60 && tries++ < 2000) {
    const x = rand(-ARENA + 3, ARENA - 3), z = rand(-ARENA + 3, ARENA - 3);
    if (!blocked(x, z, 0, 0.9)) WAYPOINTS.push([x, z]);
  }
}

/* ================= 战斗 ================= */
const S = { playing: false, paused: false, over: false, t: CFG.time, score: { blue: 0, red: 0 }, respawnT: 0 };
const feed = $('feed');
function addFeed(killer, victim, kteam, head) {
  const d = document.createElement('div');
  const col = t => t === 'blue' ? '#7ab8ff' : '#ff8a7a';
  d.innerHTML = `<span style="color:${col(kteam)}">${killer}</span> ${head ? '💥' : '➤'} <span style="color:${col(kteam === 'blue' ? 'red' : 'blue')}">${victim}</span>`;
  feed.appendChild(d); setTimeout(() => d.remove(), 5000); while (feed.children.length > 5) feed.firstChild.remove();
}
function showMsg(t, ms = 1600) { const m = $('msg'); m.textContent = t; m.style.opacity = 1; clearTimeout(showMsg.h); showMsg.h = setTimeout(() => m.style.opacity = 0, ms); }
function hitMarker(kill, head) {
  const h = $('hitm'); h.style.setProperty('--c', kill ? '#ff4040' : head ? '#ffd040' : '#fff'); h.style.opacity = 1;
  clearTimeout(hitMarker.h); hitMarker.h = setTimeout(() => h.style.opacity = 0, 140);
}
function scoreFor(team) { S.score[team]++; $('sb').textContent = S.score.blue; $('sr').textContent = S.score.red; if (S.score[team] >= CFG.goal) endGame(team); }

function killBot(b, killer, head) {
  b.alive = false; b.dead = 0; b.target = null;
  addFeed(killer.name, b.name, killer.team, head); scoreFor(killer.team); killer.kills = (killer.kills || 0) + 1;
}
function hurtPlayer(dmg, from) {
  if (!P.alive || S.over) return;
  P.hp -= dmg; P.lastHit = performance.now(); sfxHurt();
  const v = $('vig'); v.style.opacity = clamp(0.4 + (100 - P.hp) / 120, 0, 1); setTimeout(() => v.style.opacity = 0, 250);
  if (P.hp <= 0) {
    P.hp = 0; P.alive = false; P.deadT = 0; P.deaths++; S.respawnT = 3;
    addFeed(from.name, '你', from.team, false); scoreFor(from.team); from.kills = (from.kills || 0) + 1;
    showMsg('你被 ' + from.name + ' 击倒了', 2600);
  }
  updateHUD();
}
function respawnPlayer() {
  const [x, z] = spawnPoint('blue'); P.x = x; P.z = z; P.y = 0; P.vy = 0; P.hp = 100; P.alive = true; P.yaw = -Math.PI * 0.75; P.pitch = 0;
  P.w = WEAPONS.map(w => ({ mag: w.mag, reserve: w.reserve })); P.reloading = 0; updateHUD();
}

const _o = new THREE.Vector3(), _d = new THREE.Vector3(), _r = new THREE.Vector3(), _u = new THREE.Vector3(), _p = new THREE.Vector3(), _m = new THREE.Vector3();
function playerFire() {
  const w = curW(), s = curS();
  if (!P.alive || S.over || P.reloading > 0 || P.swap > 0 || P.fireCD > 0) return;
  if (s.mag <= 0) { sfxTone(200, 0.05, 0.1); P.fireCD = 0.25; startReload(); return; }
  s.mag--; P.fireCD = w.rof; P.kick = Math.min(1.6, P.kick + (w.id === 'shotgun' ? 1.2 : 0.55));
  camera.getWorldPosition(_o); camera.getWorldDirection(_d);
  _r.crossVectors(_d, camera.up).normalize(); _u.crossVectors(_r, _d).normalize();
  const mv = (Math.abs(input.mx) + Math.abs(input.my) > 0.1) ? 1.7 : 1, air = P.ground ? 1 : 2.5;
  const muz = guns[P.wi].userData.muz.clone(); guns[P.wi].localToWorld(muz);
  let anyHit = false, anyKill = false, anyHead = false;
  for (let i = 0; i < w.pellets; i++) {
    const sp = w.spread * mv * air;
    _m.copy(_d).addScaledVector(_r, (Math.random() - 0.5) * 2 * sp).addScaledVector(_u, (Math.random() - 0.5) * 2 * sp).normalize();
    let best = rayWorld(_o.x, _o.y, _o.z, _m.x, _m.y, _m.z, w.range), hitBot = null, head = false;
    for (const b of bots) {
      if (!b.alive || b.team === P.team) continue;
      const t = rayBox(_o.x, _o.y, _o.z, _m.x, _m.y, _m.z, b.x - 0.32, b.x + 0.32, b.y, b.y + BODY_H, b.z - 0.32, b.z + 0.32);
      if (t < best) { best = t; hitBot = b; head = (_o.y + _m.y * t) > b.y + 1.5; }
    }
    _p.copy(_m).multiplyScalar(best).add(_o);
    tracer(muz, _p);
    if (hitBot) {
      anyHit = true; anyHead = anyHead || head; spark(_p, 0xff3030, 5);
      hitBot.hp -= w.dmg * (head ? 2.5 : 1);
      if (hitBot.hp <= 0 && hitBot.alive) { killBot(hitBot, P, head); anyKill = true; }
    } else spark(_p, 0xffd080, 3);
  }
  if (anyHit) { hitMarker(anyKill, anyHead); sfxHit(anyHead); }
  sfxShot(w.id, 1); flashT = 0.045; guns[P.wi].userData.flash.visible = true; guns[P.wi].userData.flash.rotation.z = Math.random() * 6;
  P.pitch += w.recoil * (0.7 + Math.random() * 0.6) * (w.id === 'shotgun' ? 1 : 1);
  P.yaw += rand(-0.5, 0.5) * w.recoil;
  updateHUD();
}

/* ================= 机器人 AI ================= */
function enemiesOf(b) {
  const l = bots.filter(o => o.alive && o.team !== b.team);
  if (P.alive && P.team !== b.team) l.push(P);
  return l;
}
function updateBot(b, dt) {
  if (!b.alive) {
    b.dead += dt; b.grp.rotation.x = Math.min(Math.PI / 2, b.dead * 5); b.grp.position.set(b.x, b.y + (b.dead > 0.2 ? 0.2 : 0), b.z);
    if (b.dead > 4) respawnBot(b); return;
  }
  const diff = CFG.diff;
  b.losT -= dt;
  if (b.losT <= 0) {
    b.losT = 0.2 + Math.random() * 0.1;
    let best = null, bd = 48;
    for (const e of enemiesOf(b)) {
      const d = Math.hypot(e.x - b.x, e.z - b.z);
      if (d < bd && hasLOS(b.x, b.y + 1.5, b.z, e.x, e.y + 1.2, e.z)) { bd = d; best = e; }
    }
    if (best && best !== b.target) b.react = rand(0.35, 0.7) / diff;
    b.target = best;
    if (b.team === 'red') { b.seen = P.alive && hasLOS(P.x, P.y + 1.5, P.z, b.x, b.y + 1.2, b.z); b.seenT = b.seen ? 0.6 : b.seenT; }
  }
  b.seenT -= dt; b.strafeT -= dt; b.fireT -= dt; b.react -= dt;
  if (b.strafeT <= 0) { b.strafe = Math.random() < 0.5 ? 1 : -1; b.strafeT = rand(0.8, 2.2); }
  let mvx = 0, mvz = 0, speed = 3.6;
  const t = b.target;
  if (t) {
    const dx = t.x - b.x, dz = t.z - b.z, dist = Math.hypot(dx, dz);
    const want = Math.atan2(-dx, -dz), diffA = wrapAng(want - b.yaw);
    b.yaw += clamp(diffA, -5.5 * dt * diff, 5.5 * dt * diff);
    const fx = -Math.sin(b.yaw), fz = -Math.cos(b.yaw), rx = Math.cos(b.yaw), rz = -Math.sin(b.yaw);
    let fw = dist > 16 ? 1 : dist < 7 ? -0.8 : 0;
    mvx = fx * fw + rx * b.strafe * 0.8; mvz = fz * fw + rz * b.strafe * 0.8;
    if (b.react <= 0 && b.fireT <= 0 && Math.abs(diffA) < 0.3 && dist < 45) {
      b.fireT = b.burst >= 5 ? (b.burst = 0, rand(0.45, 0.9) / diff) : 0.16 + Math.random() * 0.05; b.burst++;
      const hitP = clamp((0.78 - dist * 0.017) * diff, 0.08, 0.6);
      const eye = _o.set(b.x - Math.sin(b.yaw) * 0.5, b.y + 1.3, b.z - Math.cos(b.yaw) * 0.5);
      const hit = Math.random() < hitP;
      const tp = _p.set(t.x, t.y + 1.2, t.z);
      if (!hit) tp.add(_m.set(rand(-1.5, 1.5), rand(-0.8, 0.8), rand(-1.5, 1.5)));
      tracer(eye, tp);
      const pd = Math.hypot(P.x - b.x, P.z - b.z); sfxShot('rifle', clamp(1 - pd / 55, 0, 0.8));
      if (hit) {
        if (t === P) hurtPlayer(7 * (diff > 1 ? 1.15 : diff < 1 ? 0.8 : 1), b);
        else if (t.alive) { t.hp -= 12; spark(tp, 0xff3030, 3); if (t.hp <= 0) killBot(t, b, false); }
      } else if (t === P && Math.random() < 0.4) sfxTone(2200, 0.04, 0.06, 'triangle');
    }
  } else {
    if (!b.wp || Math.hypot(b.wp[0] - b.x, b.wp[1] - b.z) < 1.6) b.wp = WAYPOINTS[(Math.random() * WAYPOINTS.length) | 0];
    const dx = b.wp[0] - b.x, dz = b.wp[1] - b.z, L = Math.hypot(dx, dz) || 1;
    mvx = dx / L; mvz = dz / L; speed = 3.2;
    b.yaw += clamp(wrapAng(Math.atan2(-dx, -dz) - b.yaw), -6 * dt, 6 * dt);
  }
  const ml = Math.hypot(mvx, mvz);
  if (ml > 0.01) { mvx /= Math.max(1, ml); mvz /= Math.max(1, ml); moveEnt(b, mvx * speed * dt, mvz * speed * dt); }
  // 卡住检测：换路点、跳
  b.stuckT += dt;
  if (b.stuckT > 0.6) {
    if (ml > 0.2 && Math.hypot(b.x - b.lx, b.z - b.lz) < 0.35) { b.wp = WAYPOINTS[(Math.random() * WAYPOINTS.length) | 0]; b.strafe *= -1; if (b.ground) b.vy = 7; }
    b.lx = b.x; b.lz = b.z; b.stuckT = 0;
  }
  physY(b, dt);
  b.grp.position.set(b.x, b.y, b.z); b.grp.rotation.y = b.yaw;
}

/* ================= 输入 ================= */
const input = { mx: 0, my: 0, fire: false, keys: {} };
let sprint = false;
function look(dx, dy, k) {
  P.yaw -= dx * k * CFG.sens; P.pitch = clamp(P.pitch - dy * k * CFG.sens, -1.45, 1.45);
}
addEventListener('keydown', e => {
  if (!S.playing) return;
  input.keys[e.code] = true;
  if (e.code === 'KeyR') startReload();
  if (e.code === 'Digit1') setWeapon(0); if (e.code === 'Digit2') setWeapon(1); if (e.code === 'Digit3') setWeapon(2);
  if (e.code === 'KeyQ') setWeapon((P.wi + 1) % 3);
  if (e.code === 'Space' && P.ground && P.alive) { P.vy = 7.6; }
});
addEventListener('keyup', e => { input.keys[e.code] = false; });
addEventListener('mousedown', e => {
  if (!S.playing || isTouch) return;
  if (document.pointerLockElement !== canvas) { canvas.requestPointerLock?.(); return; }
  if (e.button === 0) input.fire = true;
});
addEventListener('mouseup', e => { if (e.button === 0) input.fire = false; });
addEventListener('mousemove', e => { if (S.playing && document.pointerLockElement === canvas) look(e.movementX, e.movementY, 0.0022); });
addEventListener('wheel', e => { if (S.playing) setWeapon((P.wi + (e.deltaY > 0 ? 1 : 2)) % 3); });
document.addEventListener('pointerlockchange', () => { if (!isTouch && S.playing && document.pointerLockElement !== canvas) pauseGame(); });

// 触屏
const touchRole = {};
const joyBase = $('joyBase'), joyKnob = $('joyKnob');
let joyC = null;
const btn = id => $(id);
document.addEventListener('touchstart', e => {
  if (!S.playing) return;
  e.preventDefault(); initAudio();
  for (const t of e.changedTouches) {
    const el = t.target.closest ? t.target.closest('.tb') : null;
    if (el) {
      const id = el.id;
      if (id === 'btnFire') { touchRole[t.identifier] = { r: 'fire', x: t.clientX, y: t.clientY }; input.fire = true; }
      else { touchRole[t.identifier] = { r: 'btn' }; if (id === 'btnJump' && P.ground && P.alive) P.vy = 7.6; if (id === 'btnReload') startReload(); if (id === 'btnSwap') setWeapon((P.wi + 1) % 3); if (id === 'btnPause') pauseGame(); }
    } else if (t.clientX < innerWidth * 0.45) {
      touchRole[t.identifier] = { r: 'joy' }; joyC = { x: t.clientX, y: t.clientY };
      joyBase.style.display = 'block'; joyBase.style.left = t.clientX + 'px'; joyBase.style.top = t.clientY + 'px'; joyKnob.style.transform = '';
    } else touchRole[t.identifier] = { r: 'look', x: t.clientX, y: t.clientY };
  }
}, { passive: false });
document.addEventListener('touchmove', e => {
  if (!S.playing) return; e.preventDefault();
  for (const t of e.changedTouches) {
    const o = touchRole[t.identifier]; if (!o) continue;
    if (o.r === 'joy' && joyC) {
      let dx = t.clientX - joyC.x, dy = t.clientY - joyC.y; const L = Math.hypot(dx, dy), M = 55;
      if (L > M) { dx *= M / L; dy *= M / L; }
      input.mx = dx / M; input.my = -dy / M; joyKnob.style.transform = `translate(${dx}px,${dy}px)`;
    } else if (o.r === 'look' || o.r === 'fire') { look(t.clientX - o.x, t.clientY - o.y, 0.0042); o.x = t.clientX; o.y = t.clientY; }
  }
}, { passive: false });
const touchEnd = e => {
  for (const t of e.changedTouches) {
    const o = touchRole[t.identifier]; if (!o) continue;
    if (o.r === 'joy') { input.mx = input.my = 0; joyBase.style.display = 'none'; joyC = null; }
    if (o.r === 'fire') input.fire = false;
    delete touchRole[t.identifier];
  }
};
document.addEventListener('touchend', touchEnd); document.addEventListener('touchcancel', touchEnd);

/* ================= HUD ================= */
function updateHUD() {
  $('hpt').textContent = Math.ceil(P.hp); $('hpb').style.width = P.hp + '%';
  $('hpb').style.background = P.hp > 50 ? 'linear-gradient(90deg,#3ecf5a,#9be84a)' : P.hp > 25 ? 'linear-gradient(90deg,#e8b03a,#f0d050)' : 'linear-gradient(90deg,#d83a3a,#f06a50)';
  const s = curS(); $('am').textContent = P.reloading > 0 ? '…' : s.mag; $('ar').textContent = s.reserve; $('wn').textContent = curW().name;
}
const mini = $('mini'), mg = mini.getContext('2d');
let miniT = 0;
function drawMini() {
  const W = 256, k = W / (ARENA * 2);
  mg.clearRect(0, 0, W, W); mg.fillStyle = 'rgba(30,40,50,.6)'; mg.fillRect(0, 0, W, W);
  mg.fillStyle = 'rgba(210,210,210,.75)';
  for (const c of colliders) if (c.maxY > 1.8 && c.minY < 1) mg.fillRect((c.minX + ARENA) * k, (c.minZ + ARENA) * k, Math.max(2, (c.maxX - c.minX) * k), Math.max(2, (c.maxZ - c.minZ) * k));
  for (const b of bots) {
    if (!b.alive) continue;
    if (b.team === 'red' && b.seenT <= 0) continue;
    mg.fillStyle = b.team === 'blue' ? '#5aa9ff' : '#ff5a4a'; mg.beginPath(); mg.arc((b.x + ARENA) * k, (b.z + ARENA) * k, 5, 0, 7); mg.fill();
  }
  if (P.alive) {
    const px = (P.x + ARENA) * k, pz = (P.z + ARENA) * k;
    mg.save(); mg.translate(px, pz); mg.rotate(-P.yaw); mg.fillStyle = '#fff'; mg.beginPath(); mg.moveTo(0, -9); mg.lineTo(6, 6); mg.lineTo(-6, 6); mg.closePath(); mg.fill(); mg.restore();
  }
}

/* ================= 游戏流程 ================= */
function pauseGame() {
  if (!S.playing || S.over) return; S.playing = false; S.paused = true;
  document.exitPointerLock?.(); input.fire = false; input.mx = input.my = 0;
  $('menuSub').textContent = '已暂停'; $('btnStart').textContent = '继续游戏'; $('menu').style.display = 'flex';
}
function enterPlay() {
  initAudio(); $('menu').style.display = 'none'; S.playing = true; S.paused = false; last = performance.now();
  if (isTouch) { try { document.documentElement.requestFullscreen?.(); screen.orientation?.lock?.('landscape').catch(() => { }); } catch (e) { } }
  else canvas.requestPointerLock?.();
}
function newMatch() {
  S.over = false; S.t = CFG.time; S.score.blue = S.score.red = 0; $('sb').textContent = $('sr').textContent = 0; $('goal').textContent = `先到 ${CFG.goal} 击杀获胜`;
  P.kills = P.deaths = 0; respawnPlayer();
  bots.forEach(b => { b.kills = 0; respawnBot(b); });
  showMsg('战斗开始！', 1800);
}
function endGame(winTeam) {
  if (S.over) return; S.over = true; S.playing = false; document.exitPointerLock?.(); input.fire = false;
  const win = winTeam ? winTeam === 'blue' : S.score.blue >= S.score.red;
  $('menuSub').innerHTML = `<b style="font-size:26px;color:${win ? '#7ab8ff' : '#ff8a7a'}">${win ? '🎉 蓝队胜利' : '💥 红队胜利'}</b><br>比分 ${S.score.blue} : ${S.score.red} · 你的击杀 ${P.kills} / 死亡 ${P.deaths}`;
  $('btnStart').textContent = '再来一局'; $('menu').style.display = 'flex';
}
$('btnStart').addEventListener('click', () => {
  CFG.sens = +$('optSens').value; CFG.diff = +$('optDiff').value;
  const sh = $('optShadow').value === '1'; CFG.shadows = sh; renderer.shadowMap.enabled = sh; sun.castShadow = sh;
  scene.traverse(o => { if (o.material) o.material.needsUpdate = true; });
  if (S.over || !S.paused) { if (S.over || !S.started) { newMatch(); S.started = true; } }
  enterPlay();
});
$('optSens').addEventListener('input', e => CFG.sens = +e.target.value);

let last = performance.now(), fpsN = 0, fpsT = 0, camShake = 0;
function tick(now) {
  requestAnimationFrame(tick);
  let dt = Math.min(0.05, (now - last) / 1000); last = now;
  fpsN++; fpsT += dt; if (fpsT > 1) { $('fps').textContent = fpsN + ' FPS'; fpsN = 0; fpsT = 0; }
  if (S.playing) update(dt);
  else if (!S.started) { // 菜单背景：缓慢环绕
    const a = now * 0.00012; camera.position.set(Math.cos(a) * 30, 14, Math.sin(a) * 30); camera.lookAt(0, 2, 0); gunRoot.visible = false;
  }
  renderer.render(scene, camera);
}
function update(dt) {
  gunRoot.visible = P.alive;
  // 时间
  S.t -= dt; const tt = Math.max(0, S.t); $('tm').textContent = Math.floor(tt / 60) + ':' + String(Math.floor(tt % 60)).padStart(2, '0');
  if (S.t <= 0) { endGame(null); return; }
  P.fireCD -= dt; P.swap -= dt; P.kick = Math.max(0, P.kick - dt * 6);
  if (P.reloading > 0) { P.reloading -= dt; if (P.reloading <= 0) { P.reloading = 0; finishReload(); } }
  if (P.alive) {
    // 移动
    let mx = input.mx, my = input.my; const k = input.keys;
    if (k.KeyW || k.ArrowUp) my += 1; if (k.KeyS || k.ArrowDown) my -= 1; if (k.KeyD || k.ArrowRight) mx += 1; if (k.KeyA || k.ArrowLeft) mx -= 1;
    const L = Math.hypot(mx, my); if (L > 1) { mx /= L; my /= L; }
    const sp = (k.ShiftLeft ? 7.4 : 5.6) * (P.reloading > 0 ? 0.85 : 1);
    const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw), rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw);
    moveEnt(P, (fx * my + rx * mx) * sp * dt, (fz * my + rz * mx) * sp * dt);
    physY(P, dt);
    P.bob += Math.hypot(mx, my) * dt * (P.ground ? 9 : 0);
    // 开火
    if (input.fire && (curW().auto || !input.held)) { playerFire(); if (!curW().auto) input.held = true; }
    if (!input.fire) input.held = false;
    // 自动回血
    if (performance.now() - P.lastHit > 6000 && P.hp < 100) { P.hp = Math.min(100, P.hp + 6 * dt); updateHUD(); }
  } else {
    P.deadT += dt; S.respawnT -= dt;
    if (S.respawnT <= 0 && !S.over) { respawnPlayer(); showMsg('重生', 900); }
  }
  // 相机
  const eye = P.alive ? 1.6 : 0.5;
  camera.position.set(P.x, P.y + eye + (P.alive ? Math.sin(P.bob) * 0.03 : 0), P.z);
  camera.rotation.set(P.pitch + P.kick * 0.012, P.yaw, P.alive ? 0 : Math.min(0.6, P.deadT * 2));
  // 枪模动画
  const rl = P.reloading > 0 ? Math.sin(Math.min(1, (1 - P.reloading / curW().reload)) * Math.PI) : 0, sw = Math.max(0, P.swap) / 0.35;
  gunRoot.position.set(0.22 + Math.sin(P.bob * 0.5) * 0.008, -0.2 + Math.abs(Math.sin(P.bob)) * 0.008 - rl * 0.18 - sw * 0.25, -0.45 + P.kick * 0.05);
  gunRoot.rotation.set(P.kick * 0.06 + rl * 0.5, 0, rl * 0.25);
  if (flashT > 0) { flashT -= dt; if (flashT <= 0) guns.forEach(g => g.userData.flash.visible = false); }
  // 机器人
  for (const b of bots) updateBot(b, dt);
  updateFx(dt);
  miniT -= dt; if (miniT <= 0) { miniT = 0.1; drawMini(); }
  // 提示换弹
  if (P.alive && curS().mag <= 0 && P.reloading <= 0 && curS().reserve > 0 && !input.fire) startReload();
  if (P.reloading > 0 || P.fireCD > -0.05) updateHUD();
}

/* ================= 启动 ================= */
(async function init() {
  await loadAllTextures((d, n) => $('load').textContent = `加载贴图 ${d}/${n}…`);
  buildMap(); genWaypoints();
  ['blue', 'blue', 'blue'].forEach((t, i) => bots.push(newBot('blue', NAMES[i])));
  ['red', 'red', 'red', 'red'].forEach((t, i) => bots.push(newBot('red', NAMES[i + 4])));
  renderer.shadowMap.enabled = true;
  const real = Object.values(TEX).filter(t => t.real).length;
  $('help').insertAdjacentHTML('beforeend', `<br>贴图：${real ? `Poly Haven CC0 联网贴图 ${real}/${Object.keys(TEXSETS).length}` : '程序生成备用贴图'}`);
  $('load').style.display = 'none';
  requestAnimationFrame(tick);
})();
