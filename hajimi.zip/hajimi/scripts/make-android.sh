#!/usr/bin/env bash
# 用仓库根目录的 icon.png 生成 Android 启动图标（方形 + 圆形），并改成全屏横屏
set -e
RES="android/app/src/main/res"
rm -rf "$RES"/mipmap-anydpi-v26   # 去掉默认自适应图标，改用我们生成的 PNG

gen() { # 目录 尺寸
  local dir="$RES/$1" s="$2" h=$(( $2 / 2 ))
  mkdir -p "$dir"
  convert icon.png -resize ${s}x${s}! -strip "$dir/ic_launcher.png"
  convert icon.png -resize ${s}x${s}! -alpha set \( -size ${s}x${s} xc:none -fill white -draw "circle $h,$h $h,0" \) -compose DstIn -composite -strip PNG32:"$dir/ic_launcher_round.png"
  convert icon.png -resize ${s}x${s}! -strip "$dir/ic_launcher_foreground.png"
}
gen mipmap-mdpi 48
gen mipmap-hdpi 72
gen mipmap-xhdpi 96
gen mipmap-xxhdpi 144
gen mipmap-xxxhdpi 192

# 横屏
MAN="android/app/src/main/AndroidManifest.xml"
sed -i 's/<activity/<activity android:screenOrientation="sensorLandscape"/' "$MAN"

# 全屏沉浸（隐藏状态栏）
STY="android/app/src/main/res/values/styles.xml"
sed -i '/AppTheme.NoActionBar/a\        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>' "$STY"
echo "icons + manifest patched"
