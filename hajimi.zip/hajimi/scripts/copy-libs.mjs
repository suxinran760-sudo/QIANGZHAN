// 把 three.js 复制到 www/lib，保证 APK 离线可用
import fs from 'node:fs';
fs.mkdirSync('www/lib', { recursive: true });
fs.copyFileSync('node_modules/three/build/three.module.js', 'www/lib/three.module.js');
console.log('three.module.js copied');
