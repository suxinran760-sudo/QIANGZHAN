#!/usr/bin/env bash
# 从 Poly Haven（CC0 公共领域）下载 1K 贴图到 www/assets/tex，打包进 APK。
# 下载失败的贴图会被跳过，游戏会自动使用程序生成的备用贴图。
set -u
OUT="www/assets/tex"
mkdir -p "$OUT"
MANIFEST="{}"

# 取某个资源的 1k jpg 地址：$1=资源id  $2=贴图类型键(Diffuse|nor_gl|Rough)
url_of() {
  curl -fsSL "https://api.polyhaven.com/files/$1" 2>/dev/null | jq -r ".\"$2\".\"1k\".jpg.url // empty"
}

# fetch_set 名称 候选id1 候选id2 ...
fetch_set() {
  local name="$1"; shift
  for id in "$@"; do
    local d; d=$(url_of "$id" Diffuse)
    [ -z "$d" ] && continue
    curl -fsSL "$d" -o "$OUT/${name}_diff.jpg" || continue
    local n r
    n=$(url_of "$id" nor_gl); [ -n "$n" ] && curl -fsSL "$n" -o "$OUT/${name}_nor.jpg" || rm -f "$OUT/${name}_nor.jpg"
    r=$(url_of "$id" Rough);  [ -n "$r" ] && curl -fsSL "$r" -o "$OUT/${name}_rough.jpg" || rm -f "$OUT/${name}_rough.jpg"
    echo "OK $name <- $id"
    MANIFEST=$(echo "$MANIFEST" | jq -c --arg k "$name" --argjson n "$([ -f "$OUT/${name}_nor.jpg" ] && echo true || echo false)" --argjson r "$([ -f "$OUT/${name}_rough.jpg" ] && echo true || echo false)" '. + {($k): {nor:$n, rough:$r}}')
    return 0
  done
  # 候选都失败：按分类取该分类下的第一个资源
  echo "WARN $name: all candidate ids failed, game will use procedural texture"
}

# 某分类下随机/第一个资源 id 列表
ids_in() { curl -fsSL "https://api.polyhaven.com/assets?t=textures&c=$1" 2>/dev/null | jq -r 'keys[]' | head -5; }

fetch_set brick    brick_wall_001 brick_wall_02 red_brick $(ids_in brick)
fetch_set concrete concrete_wall_008 concrete_wall_004 concrete_floor_worn_001 $(ids_in concrete)
fetch_set asphalt  asphalt_02 asphalt_04 asphalt_01 $(ids_in asphalt)
fetch_set metal    corrugated_iron rusty_metal_02 metal_plate $(ids_in metal)
fetch_set wood     wood_planks_dirt wood_plank_wall plank_flooring_04 $(ids_in wood)

echo "$MANIFEST" > "$OUT/manifest.json"
echo "manifest: $(cat "$OUT/manifest.json")"
exit 0
